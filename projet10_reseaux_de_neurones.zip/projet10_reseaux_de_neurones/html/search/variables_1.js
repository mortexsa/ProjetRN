var searchData=
[
  ['b',['b',['../structPixel.html#a760bdf29b15433d257f119239fcff4d4',1,'Pixel::b()'],['../structCOUCHE.html#ae39541beb5026e0dc23b79066d841d8a',1,'COUCHE::B()']]]
];
