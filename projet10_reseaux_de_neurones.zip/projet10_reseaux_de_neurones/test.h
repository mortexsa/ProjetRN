#include "interface.h"

void test_chargerMNIST(char* path);
void test_ChargerEtiquetteMNIST(char* path);
void test_ChargementCoupleAttIn(char* path);
void test_Apprentissage(char* path);
void test_reconnaissance(char* path);

void test_MultiplicationMatricielleTransposeeTM();
void test_MultiplicationMatricielleTransposeeMT();
void test_Propagation();
void test_BackProp();
