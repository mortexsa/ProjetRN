var searchData=
[
  ['b',['b',['../structPixel.html#a760bdf29b15433d257f119239fcff4d4',1,'Pixel::b()'],['../structCOUCHE.html#ae39541beb5026e0dc23b79066d841d8a',1,'COUCHE::B()']]],
  ['backprop',['BackProp',['../Apprentissage_8c.html#ad11c1cb76d7860d651b3ca20b5c9cb9b',1,'Apprentissage.c']]],
  ['bmphead',['BMPHead',['../structBMPHead.html',1,'']]],
  ['bmpimhead',['BMPImHead',['../structBMPImHead.html',1,'']]]
];
